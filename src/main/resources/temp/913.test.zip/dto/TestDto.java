package com.gy.tg.test.dto;

import com.gy.tg.generator.util.MapperUtil;
import com.gy.tg.test.entity.Test;
import lombok.Data;

@Data
public class TestDto {

  private Long testId;

  public static TestDto of(Test test) {
    return MapperUtil.map(test, TestDto.class);
  }
}
