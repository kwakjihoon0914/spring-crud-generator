package com.gy.tg.test.controller;

import com.gy.tg.test.service.TestService;
import com.gy.tg.test.dto.TestDto;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@AllArgsConstructor
public class TestController {

  private final TestService testService;

  @GetMapping("/tests/{testId}")
  public ResponseEntity<TestDto> getTest(@PathVariable Long testId) {

    TestDto test = testService.getTestById(testId);
    return ResponseEntity.ok(test);
  }

  @GetMapping("/tests")
  public ResponseEntity<List<TestDto>> getTestList() {

    List<TestDto> testList = testService.getTestList();
    return ResponseEntity.ok(testList);
  }

  @PostMapping("/tests")
  public ResponseEntity<TestDto> createTest(TestDto test) {
    TestDto testDto = testService.createTest(test);
    return ResponseEntity.ok(test);
  }

  @PutMapping("/tests")
  public ResponseEntity<TestDto> updateTest(TestDto test) {
    TestDto testDto = testService.updateTest(test);
    return ResponseEntity.ok(test);
  }

  @DeleteMapping("/tests/{testId}")
  public ResponseEntity<Long> deleteTest(@PathVariable Long testId) {
    testService.deleteTestById(testId);
    return ResponseEntity.ok(testId);
  }
}
