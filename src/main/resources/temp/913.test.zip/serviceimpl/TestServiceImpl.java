package com.gy.tg.test.service;

import java.util.List;
import java.util.stream.Collectors;

import com.gy.tg.test.repository.TestRepository;
import com.gy.tg.test.dto.TestDto;
import com.gy.tg.test.entity.Test;

import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor
public class TestServiceImpl implements TestService {

  private final TestRepository testRepository;

  public List<TestDto> getTestList() {
    return testRepository.findAll().stream().map(TestDto::of).collect(Collectors.toList());
  }

  public TestDto getTestById(Long testId) {
    return TestDto.of(testRepository.findById(testId).get());
  }

  public TestDto updateTest(TestDto testDto) {

    Test created = Test.of(testDto);
    return TestDto.of(testRepository.save(created));
  }

  public TestDto createTest(TestDto testDto) {

    Test updated = Test.of(testDto);
    return TestDto.of(testRepository.save(updated));
  }

  public Long deleteTestById(Long testId) {
    testRepository.deleteById(testId);
    return testId;
  }
}
