package com.gy.tg.test.entity;

import com.gy.tg.generator.util.MapperUtil;
import com.gy.tg.test.dto.TestDto;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.Type;

@Entity
@Table(name = "TB_TEST")
@NoArgsConstructor(access = AccessLevel.PROTECTED)
public class Test {

  @Id
  @Column(name = "TEST_ID")
  private Long testId;

  public static Test of(TestDto testDto) {
    return MapperUtil.map(testDto, Test.class);
  }
}
