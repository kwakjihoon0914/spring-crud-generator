package com.gy.tg.test.service;

import java.util.List;
import com.gy.tg.test.dto.TestDto;

public interface TestService {

  List<TestDto> getTestList();

  TestDto getTestById(Long testId);

  TestDto updateTest(TestDto test);

  TestDto createTest(TestDto test);

  Long deleteTestById(Long testId);
}
