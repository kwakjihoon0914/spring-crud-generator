package com.gy.tg.employee.controller;

import com.gy.tg.employee.service.EmployeeService;
import com.gy.tg.employee.dto.EmployeeDto;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@AllArgsConstructor
public class EmployeeController {

  private final EmployeeService employeeService;

  @GetMapping("/employees/{resNo}")
  public ResponseEntity<EmployeeDto> getEmployee(@PathVariable String resNo) {

    EmployeeDto employee = employeeService.getEmployeeById(resNo);
    return ResponseEntity.ok(employee);
  }

  @GetMapping("/employees")
  public ResponseEntity<List<EmployeeDto>> getEmployeeList() {

    List<EmployeeDto> employeeList = employeeService.getEmployeeList();
    return ResponseEntity.ok(employeeList);
  }

  @PostMapping("/employees")
  public ResponseEntity<EmployeeDto> createEmployee(EmployeeDto employee) {
    EmployeeDto employeeDto = employeeService.createEmployee(employee);
    return ResponseEntity.ok(employee);
  }

  @PutMapping("/employees")
  public ResponseEntity<EmployeeDto> updateEmployee(EmployeeDto employee) {
    EmployeeDto employeeDto = employeeService.updateEmployee(employee);
    return ResponseEntity.ok(employee);
  }

  @DeleteMapping("/employees/{resNo}")
  public ResponseEntity<String> deleteEmployee(@PathVariable String resNo) {
    employeeService.deleteEmployeeById(resNo);
    return ResponseEntity.ok(resNo);
  }
}
