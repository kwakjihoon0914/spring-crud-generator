package com.gy.tg.employee.dto;

import com.gy.tg.generator.util.MapperUtil;
import com.gy.tg.employee.entity.Employee;
import lombok.Data;

@Data
public class EmployeeDto {

  private String resNo;

  public static EmployeeDto of(Employee employee) {
    return MapperUtil.map(employee, EmployeeDto.class);
  }
}
