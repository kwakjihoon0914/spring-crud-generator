package com.gy.tg.employee.service;

import java.util.List;
import java.util.stream.Collectors;

import com.gy.tg.employee.repository.EmployeeRepository;
import com.gy.tg.employee.dto.EmployeeDto;
import com.gy.tg.employee.entity.Employee;

import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor
public class EmployeeServiceImpl implements EmployeeService {

  private final EmployeeRepository employeeRepository;

  public List<EmployeeDto> getEmployeeList() {
    return employeeRepository.findAll().stream().map(EmployeeDto::of).collect(Collectors.toList());
  }

  public EmployeeDto getEmployeeById(String resNo) {
    return EmployeeDto.of(employeeRepository.findById(resNo).get());
  }

  public EmployeeDto updateEmployee(EmployeeDto employeeDto) {

    Employee created = Employee.of(employeeDto);
    return EmployeeDto.of(employeeRepository.save(created));
  }

  public EmployeeDto createEmployee(EmployeeDto employeeDto) {

    Employee updated = Employee.of(employeeDto);
    return EmployeeDto.of(employeeRepository.save(updated));
  }

  public String deleteEmployeeById(String resNo) {
    employeeRepository.deleteById(resNo);
    return resNo;
  }
}
