package com.gy.tg.employee.entity;

import com.gy.tg.generator.util.MapperUtil;
import com.gy.tg.employee.dto.EmployeeDto;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.Type;

@Entity
@Table(name = "EMPLOYEE")
@NoArgsConstructor(access = AccessLevel.PROTECTED)
public class Employee {

  @Id
  @Column(name = "RES_NO")
  private String resNo;

  public static Employee of(EmployeeDto employeeDto) {
    return MapperUtil.map(employeeDto, Employee.class);
  }
}
