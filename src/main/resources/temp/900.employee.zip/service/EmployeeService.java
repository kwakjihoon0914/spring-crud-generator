package com.gy.tg.employee.service;

import java.util.List;
import com.gy.tg.employee.dto.EmployeeDto;

public interface EmployeeService {

  List<EmployeeDto> getEmployeeList();

  EmployeeDto getEmployeeById(String resNo);

  EmployeeDto updateEmployee(EmployeeDto employee);

  EmployeeDto createEmployee(EmployeeDto employee);

  String deleteEmployeeById(String resNo);
}
